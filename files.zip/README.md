# Electronics Inventory Control Dashboard

An interactive Streamlit dashboard for inventory planning and stockout risk analysis,
built on a multi-store, multi-region electronics retail dataset (731 days, 5 stores, 20 SKUs).

## What it does

- **Reorder point & safety stock calculator** — adjustable lead time, target service
  level, and review period drive a standard (Q, R) inventory model:
  - `Safety Stock = Z(service level) × σ(demand) × √(lead time)`
  - `Reorder Point = (avg daily demand × lead time) + Safety Stock`
- **Demand forecast accuracy** — actual vs. forecasted weekly demand, with MAPE.
- **Stockout risk** — % of days inventory fell below same-day demand, broken out by store.
- **Regional demand patterns** — average daily demand by region.
- **Promotion impact** — how holiday/promo days shift demand vs. normal days.

## Why electronics

High unit cost, long supplier lead times, and high obsolescence risk make electronics
one of the categories most sensitive to the safety stock vs. holding cost tradeoff —
the core balancing act in inventory planning.

## Run it

```bash
pip install streamlit pandas numpy plotly scipy
streamlit run app.py
```

## Data

Synthetic retail inventory dataset (Kaggle), filtered to the Electronics category.

## Stack

Python, Pandas, NumPy, SciPy (z-score/service level), Plotly, Streamlit.
